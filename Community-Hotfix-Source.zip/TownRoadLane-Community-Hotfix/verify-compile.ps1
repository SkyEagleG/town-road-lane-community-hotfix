param(
    [Parameter(Mandatory=$true)][string]$ManagedPath,
    [Parameter(Mandatory=$true)][string]$GeneratorsPath,
    [Parameter(Mandatory=$true)][string]$CscPath
)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$taskOutput = Join-Path $taskRoot 'verification'
New-Item -ItemType Directory -Force $taskOutput | Out-Null
$project = Join-Path $taskRoot 'src/TownRoadLane'
[xml]$projectXml = Get-Content (Join-Path $project 'TownRoadLane.csproj') -Raw
$references = @('mscorlib','netstandard','System','System.Core','System.Data') + @($projectXml.Project.ItemGroup.Reference | ForEach-Object { $_.Include } | Where-Object { $_ -and $_ -notmatch '\$' })
$arguments = @('/noconfig','/nostdlib+','/target:library','/langversion:12.0','/optimize+','/deterministic+','/debug:portable',('/out:' + (Join-Path $taskOutput 'TownRoadLane.dll')))
foreach ($reference in ($references | Select-Object -Unique)) {
    $referenceFile = Join-Path $ManagedPath ($reference + '.dll')
    if (!(Test-Path -LiteralPath $referenceFile)) { throw "Missing game reference: $referenceFile" }
    $arguments += '/reference:' + $referenceFile
}
$arguments += Get-ChildItem -LiteralPath $GeneratorsPath -Filter '*.dll' | ForEach-Object { '/analyzer:' + $_.FullName }
$arguments += Get-ChildItem -LiteralPath $project -Filter '*.cs' -Recurse | Where-Object { $_.FullName -notmatch '[\\/](Diagnostics|obj|bin)[\\/]' } | ForEach-Object { $_.FullName }
$assemblyInfo = Join-Path $taskOutput 'AssemblyInfo.cs'
Set-Content -LiteralPath $assemblyInfo -Value '[assembly:System.Reflection.AssemblyVersion("2.5.0.1")][assembly:System.Reflection.AssemblyInformationalVersion("2.5.0-community-hotfix.1-review")][assembly:System.Reflection.AssemblyDescription("Community hotfix of mxerf Town Road Lane; AI-assisted development; runtime validation pending")]'
$arguments += $assemblyInfo
& dotnet $CscPath @arguments
if ($LASTEXITCODE -ne 0) { throw "Reference compilation failed ($LASTEXITCODE)" }
Write-Output 'Reference compilation passed. This assembly has NOT been Burst-postprocessed or approved for installation.'
