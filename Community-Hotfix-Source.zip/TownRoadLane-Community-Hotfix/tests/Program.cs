using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Colossal.Logging;
using Colossal.Serialization.Entities;
using TownRoadLane.Components;
using TownRoadLane.Utilities;
using Unity.Entities;
using Unity.Mathematics;

internal static class Program
{
    private static int _passed;
    private static void Check(bool condition, string message)
    { if (!condition) throw new Exception(message); }
    private static void Test(string name, Action action)
    { action(); ++_passed; Console.WriteLine("PASS " + name); }

    private sealed class Tokens : IReader, IWriter
    {
        public readonly List<object> Values;
        public int Position;
        public Tokens(params object[] values) { Values = new List<object>(values); }
        public void Write<T>(T value) { Values.Add(value); }
        public void Read<T>(out T value) { value = (T)Values[Position++]; }
    }

    private static void Layout<T>(T sample, params object[] expected) where T : struct, ISerializable
    {
        var written = new Tokens();
        sample.Serialize(written);
        Check(written.Values.SequenceEqual(expected), typeof(T).Name + " writer layout changed");
        var input = new Tokens(expected.Concat(new object[] { "sentinel" }).ToArray());
        T read = default;
        read.Deserialize(input);
        Check(read.Equals(sample), typeof(T).Name + " round-trip changed fields");
        Check(input.Position == expected.Length, "reader consumed wrong field count");
    }

    private static void Reject<T>(int version) where T : struct, ISerializable
    {
        var input = new Tokens(version, "payload-must-not-be-read");
        T value = default;
        try { value.Deserialize(input); throw new Exception("unsupported version accepted"); }
        catch (InvalidDataException) { Check(input.Position == 1, "unknown layout consumed payload"); }
    }

    private sealed class BrokenLog : ILog
    {
        public int Calls;
        public bool Fail;
        public bool isDebugEnabled => true;
        public Level effectivenessLevel { get; set; }
        public bool isLevelEnabled(Level level) => true;
        public void Log(Level level, string message, Exception exception)
        { ++Calls; if (Fail) throw new NullReferenceException("simulated logger file failure"); }
    }

    public static int Main()
    {
        try
        {
            var a = new Entity { Index = 12, Version = 2 };
            var b = new Entity { Index = 29, Version = 5 };
            var pos = new float3(3f, 7f, 11f);
            Test("MarkingPair v2 unchanged layout", () => Layout(new MarkingPair { sourceEdge = a, sourceGapIndex = 1, targetEdge = b, targetGapIndex = 2 }, 2, a, 1, b, 2));
            Test("MarkingLine v4 unchanged layout", () => Layout(new MarkingLine { sourceEdge = a, sourceGapIndex = 1, targetEdge = b, targetGapIndex = 2, style = 3, curvature = 0.4f }, 4, a, 1, b, 2, 3, 0.4f));
            Test("MarkingSegment v2 unchanged layout", () => Layout(new MarkingSegment { lineIndex = 2, tStart = 0.2f, tEnd = 0.9f, visible = true, style = 3 }, 2, 2, 0.2f, 0.9f, true, 3));
            Test("MarkingArea v1 unchanged layout", () => Layout(new MarkingArea { styleId = 8, visible = true, firstVertex = 2, vertexCount = 4 }, 1, 8, true, 2, 4));
            Test("MarkingAreaVertex v2 unchanged layout", () => Layout(new MarkingAreaVertex { kind = AreaAnchorKind.NodeCorner, refIndex = 3, edgeToNext = AreaEdgeKind.LineBezier, refEdgeA = a, refEdgeB = b, refGap = 2, refPos = pos }, 2, (byte)1, 3, (byte)1, a, b, 2, pos));
            Test("TRLAreaLink v1 unchanged layout", () => Layout(new TRLAreaLink { node = a, areaIndex = 2, pieceIndex = 3 }, 1, a, 2, 3));
            Test("MarkingAreaPiece v1 unchanged layout", () => Layout(new MarkingAreaPiece { areaIndex = 2, pieceIndex = 3, visible = true, firstVertex = 1, vertexCount = 5, centroid = pos }, 1, 2, 3, true, 1, 5, pos));
            Test("MarkingAreaPieceVertex v1 unchanged layout", () => Layout(new MarkingAreaPieceVertex { position = pos }, 1, pos));
            Test("MarkingOverride v1 unchanged layout", () => Layout(new MarkingOverride { hide = MarkingCategory.All }, 1, uint.MaxValue));
            Test("legacy line v3 reads without taking next field", () =>
            {
                var t = new Tokens(3, a, 1, b, 2, 3, "next"); var value = new MarkingLine(); value.Deserialize(t);
                Check(value.curvature == 0.4f && t.Position == 6, "legacy curvature or field count");
            });
            Test("legacy segment v1 reads without style", () =>
            {
                var t = new Tokens(1, 2, 0.1f, 0.8f, true, "next"); var value = new MarkingSegment(); value.Deserialize(t);
                Check(value.style == 0 && t.Position == 5, "legacy style or field count");
            });
            Test("legacy area vertex v1 reads without stable identity", () =>
            {
                var t = new Tokens(1, (byte)0, 5, (byte)1, "next"); var value = new MarkingAreaVertex(); value.Deserialize(t);
                Check(value.IsLegacyIndexRef && value.refEdgeA == Entity.Null && t.Position == 4, "legacy vertex layout");
            });
            Test("unknown versions stop before payload", () =>
            {
                Reject<MarkingLine>(2); Reject<MarkingLine>(5); Reject<MarkingPair>(1); Reject<MarkingPair>(3);
                Reject<MarkingSegment>(0); Reject<MarkingSegment>(3); Reject<MarkingArea>(2);
                Reject<MarkingAreaVertex>(3); Reject<TRLAreaLink>(2); Reject<MarkingAreaPiece>(2);
                Reject<MarkingAreaPieceVertex>(2); Reject<MarkingOverride>(2);
            });
            Test("readiness polling is bounded and stops after success", () =>
            {
                var gate = new InitializationWindow(); int attempts = 0;
                for (int i = 0; i < 10000; ++i) if (gate.ShouldAttempt(i / 1000f)) ++attempts;
                Check(attempts <= 20 && attempts > 0, "per-frame readiness work");
                gate.Complete(); Check(!gate.ShouldAttempt(30f) && !gate.Expired, "completion replayed");
            });
            Test("readiness timeout is terminal", () =>
            {
                var gate = new InitializationWindow(); Check(gate.ShouldAttempt(50f), "initial attempt missing");
                Check(!gate.ShouldAttempt(170f) && gate.Expired && !gate.ShouldAttempt(171f), "timeout replayed mutation");
            });
            Test("long prefab boot does not consume readiness timeout", () =>
            {
                var gate = new InitializationWindow();
                for (int i = 0; i < 900; ++i) gate.ShouldAttempt(i, loading: true);
                Check(!gate.Expired && gate.ShouldAttempt(900f), "legitimate long boot expired");
                Check(!gate.ShouldAttempt(1020f) && gate.Expired, "post-loading timeout missing");
            });
            Test("loading pauses and resets a running readiness deadline", () =>
            {
                var gate = new InitializationWindow(); gate.ShouldAttempt(0f); gate.ShouldAttempt(110f);
                gate.ShouldAttempt(111f, loading: true); gate.ShouldAttempt(800f, loading: true);
                Check(gate.ShouldAttempt(801f) && !gate.Expired, "loading resumed an expired deadline");
                Check(gate.ShouldAttempt(920f), "deadline resumed too early");
                Check(!gate.ShouldAttempt(921f) && gate.Expired, "reset deadline never expired");
            });
            Test("settings writes are single-flight and retain newer edits", () =>
            {
                var tasks = new List<TaskCompletionSource>(); int state = 1; var snapshots = new List<int>();
                var q = new CoalescedSave(() => { snapshots.Add(state); var t = new TaskCompletionSource(); tasks.Add(t); return t.Task; }, error => Check(error == null, "unexpected error"));
                q.MarkDirty(0f); q.Tick(1f); Check(tasks.Count == 0, "quiet period ignored"); q.Tick(2f);
                state = 2; q.MarkDirty(3f); q.Tick(20f); Check(tasks.Count == 1, "overlapping write");
                tasks[0].SetResult(); q.Tick(21f); Check(tasks.Count == 2 && snapshots.SequenceEqual(new[] { 1, 2 }), "newer state lost");
                tasks[1].SetResult(); q.Stop(); Check(q.Tick(22f), "completed queue not unregistered");
            });
            Test("settings faults are observed on the polling thread", () =>
            {
                Exception observed = null; var t = new TaskCompletionSource();
                var q = new CoalescedSave(() => t.Task, error => observed = error); q.MarkDirty(0); q.Tick(2);
                t.SetException(new IOException("disk failure")); Check(observed == null, "off-thread reporting");
                q.Tick(3); Check(observed is IOException, "fault unobserved");
            });
            Test("synchronous save failure is reported once", () =>
            {
                int reports = 0; var q = new CoalescedSave(() => throw new IOException(), error => ++reports);
                q.MarkDirty(0); q.Tick(2); q.Tick(3); Check(reports == 1, "failure floods updates");
            });
            Test("dispose flushes dirty settings and ignores later edits", () =>
            {
                int writes = 0; var q = new CoalescedSave(() => { ++writes; return Task.CompletedTask; }, _ => { });
                q.MarkDirty(0); q.Stop(); q.MarkDirty(10); q.Tick(0); Check(q.Tick(0) && writes == 1, "dispose lost or duplicated pending state");
            });
            Test("cancelled saves are observed", () =>
            {
                Exception observed = null; var q = new CoalescedSave(() => Task.FromCanceled(new System.Threading.CancellationToken(true)), e => observed = e);
                q.MarkDirty(0); q.Tick(2); q.Tick(3); Check(observed is TaskCanceledException, "cancel unobserved");
            });
            Test("logger failure cannot flood or escape into simulation", () =>
            {
                var raw = new BrokenLog { Fail = true }; var safe = new SafeLog(raw);
                for (int i = 0; i < 100000; ++i) safe.Warn("unresolved");
                Check(raw.Calls == 1 && UnityEngine.Debug.FallbackWarnings == 1 && !safe.isDebugEnabled, "logger failure repeated");
            });
            Test("healthy logging still forwards", () =>
            { var raw = new BrokenLog(); var safe = new SafeLog(raw); safe.Info("ok"); safe.Error(new IOException(), "fault"); Check(raw.Calls == 2, "healthy logs suppressed"); });
            Test("compatibility requires both reviewed hashes", () =>
            {
                Check(CompatibilityBaseline.MatchesReviewedHashes(CompatibilityBaseline.GameHash, CompatibilityBaseline.EntitiesHash), "reviewed pair rejected");
                Check(!CompatibilityBaseline.MatchesReviewedHashes("different", CompatibilityBaseline.EntitiesHash), "unknown game accepted");
                Check(!CompatibilityBaseline.MatchesReviewedHashes(CompatibilityBaseline.GameHash, "different"), "unknown ECS accepted");
                Check(!CompatibilityBaseline.MatchesReviewedHashes(null, null), "missing files accepted");
            });
            Test("unreviewed assemblies leave compatibility gate closed", () =>
            { Check(!CompatibilityBaseline.IsSupported(out var reason) && !string.IsNullOrEmpty(reason), "unknown assembly gate opened"); });
            Console.WriteLine($"{_passed} regression tests passed. Unity runtime behavior is not covered by these tests.");
            return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }
}
