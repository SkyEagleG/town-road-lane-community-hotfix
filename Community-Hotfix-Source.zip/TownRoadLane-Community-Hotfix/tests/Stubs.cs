using System;
using System.Collections.Generic;

// These doubles exercise pure control flow and the real serialization methods without loading
// Unity. They do not model a running ECS world or replace the required in-game validation.
namespace Colossal.Serialization.Entities
{
    public interface IWriter { void Write<T>(T value); }
    public interface IReader { void Read<T>(out T value); }
    public interface ISerializable
    {
        void Serialize<T>(T writer) where T : IWriter;
        void Deserialize<T>(T reader) where T : IReader;
    }
    [AttributeUsage(AttributeTargets.Struct)]
    public sealed class FormerlySerializedAsAttribute : Attribute
    { public FormerlySerializedAsAttribute(string name) { } }
}
namespace Unity.Entities
{
    public interface IComponentData { }
    public interface IBufferElementData { }
    [AttributeUsage(AttributeTargets.Struct)]
    public sealed class InternalBufferCapacityAttribute : Attribute
    { public InternalBufferCapacityAttribute(int capacity) { } }
    public struct Entity : IEquatable<Entity>
    {
        public int Index, Version;
        public static Entity Null => default;
        public bool Equals(Entity other) => Index == other.Index && Version == other.Version;
        public override bool Equals(object value) => value is Entity other && Equals(other);
        public override int GetHashCode() => HashCode.Combine(Index, Version);
        public static bool operator ==(Entity left, Entity right) => left.Equals(right);
        public static bool operator !=(Entity left, Entity right) => !left.Equals(right);
    }
    public struct DynamicBuffer<T>
    {
        private List<T> _values;
        public DynamicBuffer(List<T> values) { _values = values; }
        public int Length => _values.Count;
        public T this[int index] => _values[index];
    }
}
namespace Unity.Mathematics
{
    public struct float3
    {
        public float x, y, z;
        public float3(float a, float b, float c) { x = a; y = b; z = c; }
        public static float3 zero => default;
    }
}
namespace TownRoadLane.Geometry
{ public static class MarkingCurveBuilder { public const float kPullFactor = 0.4f; } }
namespace TownRoadLane.Systems.Emission { }
namespace Game.Net { public sealed class SecondaryLaneSystem { } }
namespace Colossal.Logging
{
    public enum Level { Debug, Info, Warn, Error }
    public interface ILog
    {
        bool isDebugEnabled { get; }
        Level effectivenessLevel { get; set; }
        bool isLevelEnabled(Level level);
        void Log(Level level, string message, Exception exception);
    }
}
namespace UnityEngine
{
    public static class Debug
    {
        public static int FallbackWarnings;
        public static void LogWarning(object message) { ++FallbackWarnings; }
    }
}
