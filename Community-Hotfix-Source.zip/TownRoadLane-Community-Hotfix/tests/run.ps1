param(
    [Parameter(Mandatory=$true)][string]$CscPath,
    [Parameter(Mandatory=$true)][string]$ReferencePath
)
$ErrorActionPreference = 'Stop'
$testOutput = Join-Path $PSScriptRoot 'bin'
New-Item -ItemType Directory -Force $testOutput | Out-Null
$source = Join-Path $PSScriptRoot '../src/TownRoadLane'
$arguments = @('/noconfig','/nostdlib+','/target:exe','/langversion:12.0',('/out:' + (Join-Path $testOutput 'Regressions.dll')))
$arguments += Get-ChildItem -LiteralPath $ReferencePath -Filter '*.dll' | ForEach-Object { '/reference:' + $_.FullName }
$arguments += @((Join-Path $PSScriptRoot 'Stubs.cs'), (Join-Path $PSScriptRoot 'Program.cs'))
foreach ($file in @('MarkingPair','MarkingLine','MarkingSegment','MarkingArea','MarkingAreaPiece','MarkingOverride')) { $arguments += Join-Path $source ('Components/' + $file + '.cs') }
foreach ($file in @('SaveVersion','CoalescedSave','InitializationWindow','SafeLog','CompatibilityBaseline')) { $arguments += Join-Path $source ('Utilities/' + $file + '.cs') }
& dotnet $CscPath @arguments
if ($LASTEXITCODE -ne 0) { throw 'Regression test compilation failed' }
Set-Content (Join-Path $testOutput 'Regressions.runtimeconfig.json') '{"runtimeOptions":{"tfm":"net10.0","framework":{"name":"Microsoft.NETCore.App","version":"10.0.0"}}}'
& dotnet (Join-Path $testOutput 'Regressions.dll')
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed' }
