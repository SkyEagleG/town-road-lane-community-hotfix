param(
    [Parameter(Mandatory=$true)][string]$CecilPath,
    [Parameter(Mandatory=$true)][string]$OriginalPath,
    [Parameter(Mandatory=$true)][string]$CandidatePath,
    [Parameter(Mandatory=$true)][string]$ResultPath
)
$ErrorActionPreference = 'Stop'
Add-Type -Path $CecilPath
$taskOriginal = [Colossal.Mono.Cecil.AssemblyDefinition]::ReadAssembly($OriginalPath)
$taskCandidate = [Colossal.Mono.Cecil.AssemblyDefinition]::ReadAssembly($CandidatePath)
try {
    if ($taskOriginal.Name.Name -ne $taskCandidate.Name.Name) { throw 'Assembly identity changed' }
    $taskResults = @()
    foreach ($taskType in $taskOriginal.MainModule.Types) {
        if (-not ($taskType.Interfaces | Where-Object { $_.InterfaceType.FullName -eq 'Colossal.Serialization.Entities.ISerializable' })) { continue }
        $taskNew = $taskCandidate.MainModule.Types | Where-Object { $_.FullName -eq $taskType.FullName }
        if (-not $taskNew) { throw "Saved type missing: $($taskType.FullName)" }
        $taskOldFields = @($taskType.Fields | Where-Object { $_.IsPublic -and -not $_.IsStatic } | ForEach-Object { "$($_.Name):$($_.FieldType.FullName)" })
        $taskNewFields = @($taskNew.Fields | Where-Object { $_.IsPublic -and -not $_.IsStatic } | ForEach-Object { "$($_.Name):$($_.FieldType.FullName)" })
        if (($taskOldFields -join '|') -ne ($taskNewFields -join '|')) { throw "Saved field layout changed: $($taskType.FullName)" }
        $taskOldAliases = @($taskType.CustomAttributes | Where-Object { $_.AttributeType.Name -like 'FormerlySerializedAs*' } | ForEach-Object { $_.ConstructorArguments[0].Value })
        $taskNewAliases = @($taskNew.CustomAttributes | Where-Object { $_.AttributeType.Name -like 'FormerlySerializedAs*' } | ForEach-Object { $_.ConstructorArguments[0].Value })
        if (($taskOldAliases -join '|') -ne ($taskNewAliases -join '|')) { throw "Saved aliases changed: $($taskType.FullName)" }
        $taskOldVersion = $taskType.Fields | Where-Object { $_.Name -eq 'kVersion' }
        $taskNewVersion = $taskNew.Fields | Where-Object { $_.Name -eq 'kVersion' }
        if ($taskOldVersion.Constant -ne $taskNewVersion.Constant) { throw "Writer version changed: $($taskType.FullName)" }
        $taskResults += [pscustomobject]@{
            type = $taskType.FullName
            fieldLayoutUnchanged = $true
            aliasesUnchanged = $true
            fieldCount = $taskOldFields.Count
            aliasCount = $taskOldAliases.Count
            writerVersion = $taskOldVersion.Constant
        }
    }
    if ($taskResults.Count -ne 9) { throw "Expected 9 saved components; checked $($taskResults.Count). Review required." }
    $taskResults | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ResultPath
    Write-Output 'Verified 9 saved component identities, public field layouts, legacy aliases, and writer versions against the installed original DLL.'
} finally {
    $taskOriginal.Dispose()
    $taskCandidate.Dispose()
}
