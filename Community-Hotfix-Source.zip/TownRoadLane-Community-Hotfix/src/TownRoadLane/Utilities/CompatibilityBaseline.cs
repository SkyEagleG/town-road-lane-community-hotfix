using System;
using System.IO;
using System.Security.Cryptography;
using Game.Net;
using Unity.Entities;

namespace TownRoadLane.Utilities
{
    internal static class CompatibilityBaseline
    {
        // Reviewed installation, not a promise about every 1.6.* binary. An unknown build must
        // be reviewed before this wholesale copy is allowed to replace its vanilla generator.
        internal const string GameHash = "AAEE15C4FA41C130ABAA1183840667E4FAAE531D67E8A9FA7536618EFFA2F86A";
        internal const string EntitiesHash = "07D9CB32BF935A88ECD5FE0BAFF31D2BC7E828F6DEA31619300A50DD9E2C2871";

        internal static bool IsSupported(out string reason)
        {
            try
            {
                string game = HashFile(typeof(SecondaryLaneSystem).Assembly.Location);
                string entities = HashFile(typeof(Entity).Assembly.Location);
                if (MatchesReviewedHashes(game, entities))
                {
                    reason = "Reviewed game and ECS assemblies matched";
                    return true;
                }
                reason = $"Town Road Lane Community Hotfix is inactive: this game/ECS build has not been reviewed. Game SHA256={game}; Entities SHA256={entities}. The vanilla generator was left enabled. Have the hotfix updated before using and saving a city that needs it.";
            }
            catch (Exception error)
            {
                reason = $"Town Road Lane Community Hotfix is inactive: compatibility could not be checked ({error.GetType().Name}: {error.Message}). The vanilla generator was left enabled.";
            }
            return false;
        }

        internal static bool MatchesReviewedHashes(string game, string entities)
            => game == GameHash && entities == EntitiesHash;

        private static string HashFile(string path)
        {
            using (var stream = File.OpenRead(path))
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "");
        }
    }
}
