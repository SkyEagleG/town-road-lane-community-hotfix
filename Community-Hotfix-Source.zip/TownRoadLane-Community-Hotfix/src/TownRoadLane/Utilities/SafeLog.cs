using System;
using System.Threading;
using Colossal.Logging;

namespace TownRoadLane.Utilities
{
    /// <summary>Diagnostics must never interrupt a simulation system when the log file fails.</summary>
    internal sealed class SafeLog
    {
        private readonly ILog _inner;
        private int _failed;

        public SafeLog(ILog inner) { _inner = inner; }
        public bool isDebugEnabled => _failed == 0 && _inner.isDebugEnabled;
        public Level effectivenessLevel { set { _inner.effectivenessLevel = value; } }
        public void Debug(object message) => Write(Level.Debug, message, null);
        public void Info(object message) => Write(Level.Info, message, null);
        public void Warn(object message) => Write(Level.Warn, message, null);
        public void Error(object message) => Write(Level.Error, message, null);
        public void Error(Exception exception, object message) => Write(Level.Error, message, exception);

        private void Write(Level level, object message, Exception exception)
        {
            if (_failed != 0) return;
            try
            {
                if (_inner.isLevelEnabled(level)) _inner.Log(level, message?.ToString() ?? "", exception);
            }
            catch (Exception failure)
            {
                if (Interlocked.Exchange(ref _failed, 1) != 0) return;
                // One fallback only; Unity may itself be unable to write Player.log.
                try { UnityEngine.Debug.LogWarning($"Town Road Lane Community Hotfix: logging disabled after {failure.GetType().Name}. Check access to the Logs folder."); }
                catch (Exception) { }
            }
        }
    }
}
