namespace TownRoadLane.Utilities
{
    /// <summary>Poll readiness with bounded work; never retry a mutation that already started.</summary>
    internal sealed class InitializationWindow
    {
        private float _started = -1f;
        private float _nextAttempt;
        public bool Finished { get; private set; }
        public bool Expired { get; private set; }

        public bool ShouldAttempt(float now, bool loading = false)
        {
            if (Finished) return false;
            // Booting prefabs can legitimately take minutes in a heavily modded playset.
            // Keep polling cheaply, but only time out once the game leaves its loading state.
            if (loading) _started = -1f;
            else if (_started < 0f) _started = now;
            if (!loading && now - _started >= 120f)
            {
                Expired = Finished = true;
                return false;
            }
            if (now < _nextAttempt) return false;
            _nextAttempt = now + 0.5f;
            return true;
        }

        public void Complete() { Finished = true; }
    }
}
