using System;
using System.Threading.Tasks;

namespace TownRoadLane.Utilities
{
    /// <summary>Polled on the main thread; async writes never overlap or mutate state off-thread.</summary>
    internal sealed class CoalescedSave
    {
        private readonly Func<Task> _write;
        private readonly Action<Exception> _report;
        private Task _inFlight;
        private bool _dirty;
        private bool _stopped;
        private float _due;

        public CoalescedSave(Func<Task> write, Action<Exception> report)
        {
            _write = write;
            _report = report;
        }

        public void MarkDirty(float now) { if (!_stopped) { _dirty = true; _due = now + 2f; } }

        public bool Tick(float now)
        {
            if (_inFlight != null)
            {
                if (!_inFlight.IsCompleted) return false;
                var error = _inFlight.IsFaulted ? _inFlight.Exception.GetBaseException()
                    : _inFlight.IsCanceled ? new TaskCanceledException(_inFlight) : null;
                _inFlight = null;
                _report(error);
            }
            if (_dirty && now >= _due)
            {
                _dirty = false;
                try { _inFlight = _write() ?? Task.CompletedTask; }
                catch (Exception error) { _report(error); }
            }
            return _stopped && !_dirty && _inFlight == null;
        }

        public void Stop() { _stopped = true; _due = 0f; }
    }
}
