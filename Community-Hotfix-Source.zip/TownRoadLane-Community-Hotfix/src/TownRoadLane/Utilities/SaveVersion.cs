using System.IO;

namespace TownRoadLane.Utilities
{
    internal static class SaveVersion
    {
        public static void RequireSupported(string component, int version, int minimum, int maximum)
        {
            if (version < minimum || version > maximum)
                throw new InvalidDataException($"Town Road Lane: unsupported {component} save version {version} (supported {minimum}..{maximum}). No fields from the unknown layout were read.");
        }
    }
}
