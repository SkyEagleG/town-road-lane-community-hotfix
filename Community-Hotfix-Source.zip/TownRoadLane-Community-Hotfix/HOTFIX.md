# Town Road Lane — Community Hotfix 1 (test candidate)

Unofficial maintenance derivative of **Town Road Lane — Road Markings by mxerf**. Based on public upstream commit `6ffd1e874ab70e60834e76ad15cae08508d991a8` (upstream 2.5.0). This derivative is not an official update by mxerf. Analysis, implementation, and verification used OpenAI Codex and AI tools. Original authorship and the GPL-3.0 license are retained. Attribution is not a claim that the original author endorses this work.

**Status on October 14, 2026: official Release test candidate built and staged in the workspace. Gameplay validation and publication remain pending. No candidate has been installed in the game or published.**

The title "Community Hotfix" identifies an unofficial maintenance effort. "Hotfix" alone would not establish authorship. The assembly and saved prefab/component identifiers deliberately retain `TownRoadLane` for save compatibility; the display name and provenance identify the derivative. Enable only one version when a validated package becomes available.

## Implemented repairs

| Problem | Repair | Important boundary |
| --- | --- | --- |
| Solid-prefab failure warns and reallocates work every update | Once-per-unresolved-streak warning; readiness work and emission retries at most twice per second; stop emission after terminal clone failure | No arbitrary repeated mutation of live prefabs |
| The logger itself throws into simulation callers | Internal SafeLog adapter stops using a failed logger and attempts one fallback warning | Public upstream ILog field retained for integrations; external callers are responsible for their logging |
| Unity ordering attributes are ineffective under Game.UpdateSystem | Explicit phase-relative registrations for the marking chain, vanilla area geometry, and replacement secondary lanes | Verified from the installed scheduler; attribute reliance was removed |
| Prefab initialization marks itself done before prerequisites exist | Read-only readiness preflight before the first mutation; bounded 120-second readiness window after boot/loading; explicit failure reporting | A partial mutation is never replayed; restart is required after terminal failure |
| Surface clone callbacks can outlive their world/mod instance | World identity, generation cancellation, existing-clone checks, and prerequisite preflight | No repeated registration of existing surface clones |
| Vanilla generator disabled before registration is complete | Commit takeover only after successful registrations; disable partial hotfix registrations on failure; restore owned vanilla enabled state on disposal | Live unloading/reloading remains unsupported because prefab mutations are not globally reversible |
| Settings writes can overlap or outlive settings registration | One polled write Task at a time; preserve edits made during an outstanding write; observe async failure on the main thread; flush pending dirty state on disposal | Applies to this mod's save queue; cannot serialize independent writes made by vanilla's nonvirtual ApplyAndSave or another mod |
| Readers accept unsupported save layouts | Validate each version before reading payload; preserve shipped writer layouts and supported older readers | Unknown layouts fail clearly rather than guessing and shifting the input stream; unshipped MarkingPair v1 is rejected |
| Legacy migration keeps a buffer across a structural change | Add all required buffers first, then reacquire them; exclude temporary/deleted entities; dispose the snapshot on every exit | Runtime migration still requires a real legacy-save test |
| Repeated area failures produce warnings and stale bookkeeping | Once-per-failure diagnostics, clear state on save load, prune dead warning/fingerprint entries | This does not claim to solve every unresolved area geometry shape |
| Main-thread area rewrite needs a clear synchronization contract | Complete component dependencies through the public EntityManager API; preserve exact relative ordering | Existing GetBuffer already synchronizes dependencies: the original audit did not prove an active race |
| Future patches can silently diverge from the copied generator | Check reviewed game/ECS assembly SHA-256 before any mod registration or takeover | An unknown build disables this hotfix; hashes require deliberate source review before updating |
| A source build could deploy automatically or update the original mod listing | Standard toolchain builds stage in this repository's artifacts folder; publishing configuration has no original ModId and explicitly labels the preview | No publication or game-folder deployment performed |

Initialization readiness uses the required vanilla lane sources and baseline mesh. Missing optional G87 styles retain upstream fallbacks. Automatic mesh/style changes remain restart-bound. If prerequisites never appear, a bounded diagnostic replaces an indefinite attempt to mutate prefabs. Existing logs showed roughly 149 seconds from OnLoad to lane-clone initialization, so the timeout explicitly excludes Booting, BootingPrefabs, and Loading. Readiness continues to be polled at most twice per second during those states.

## Compatibility evidence

The local installed `Game.Version.current` decodes to **1.6.2f1**. The installed `Unity.Entities` toolchain version is **1.3.10**.

Reviewed assembly fingerprints:

```text
Game.dll
AAEE15C4FA41C130ABAA1183840667E4FAAE531D67E8A9FA7536618EFFA2F86A
Unity.Entities.dll
07D9CB32BF935A88ECD5FE0BAFF31D2BC7E828F6DEA31619300A50DD9E2C2871
```

The installed SecondaryLaneSystem was decompiled and compared with the copied implementation. The observed differences are the documented marking overrides, namespace/alias adaptations, generated-handle access, and equivalent decompiler syntax/control-flow rendering. No new game-version-specific algorithm repair was justified by that comparison. The large copied lane-generation algorithm is left unchanged.

This is source review plus compilation evidence, not a formal proof of semantic equivalence or runtime compatibility. Game/ECS hashes intentionally reject even a nominally identical version with different binaries. This is conservative and can require a hotfix review after unrelated game updates. It protects against silently running an unreviewed copy; it does not make the copy automatically support future updates.

The installed Game.UpdateSystem sorts by registration and explicit reference registrations; it does not inspect Unity UpdateBefore/UpdateAfter attributes. The installed SystemOrder puts secondary lanes in Modification4B and area geometry in Modification2B. Unity's EntityDataAccess.GetBuffer completes the relevant component dependencies, so an unconditional race claim would be inaccurate. The proposed upstream PR #5's access to another system's protected Dependency did not compile; this derivative instead uses public component-dependency completion.

## Verification completed

- The official Release build succeeded with **0 warnings and 0 errors**, including official Unity/Colossal IL post-processing and Burst native compilation for Windows, macOS, and Linux. The candidate's gameplay validation target is Windows; compilation alone does not establish gameplay support on any platform.
- **26 focused regression tests passed** outside the restricted session. The two new loading tests prevent a legitimate long prefab boot from consuming the readiness deadline. The original nine serialized layouts and three supported legacy reader layouts remain covered.
- TypeScript type checking and production UI bundling passed. The standalone frontend build reports an existing Sass legacy-API deprecation warning; the official MSBuild invocation itself finished with zero reported warnings.
- C# whitespace formatting completed under normal user access. A final verification run accompanies the candidate.
- The copied lane generator was compared with the installed vanilla implementation; its large core algorithm remains unchanged.
- A metadata comparison of the postprocessed candidate against the installed original confirms all **nine saved component identities, public field layouts, legacy aliases, and writer-version constants** are unchanged. This is additional binary evidence, not a substitute for a real save/reload test.
- Game/ECS hashes match the reviewed 1.6.2f1 baseline. The installed original mod is **2.5.0.0**, cached package **150863_15**, managed DLL SHA256 **78C7B33BD826C78DB8249C9B19B2D131D36570B36852F204FDFFF56DB02C3B5B**.
- Required asset packs are cached as **97828_5**, **98624_2**, and **99062_2**. These suffixes are package revisions, not verified semantic version numbers; their enabled state must be checked in the test playset.

The regression suite links real component serialization and helper source to small test doubles. It does not execute a Unity world, perform actual game serialization/entity remapping, exercise native/Burst code in the game, render markings, or simulate another mod.

The earlier toolchain/test-access failures were resolved by running authorized checks outside the restricted execution environment. Normal user access exposes CSII_UNITYVERSION=2022.3.62f2 and the registered editor at C:\Program Files\Unity 2022.3.62f2. No toolchain reinstall or Windows security-setting change was needed. The earlier Application Control block did not recur in that environment; all 26 tests now execute successfully.

Existing logs were read and preserved privately in work/evidence. The original TownRoadLane.Mod.log snapshot is approximately 1.6 KB and contains startup/initialization messages rather than an extreme logging flood. Player.log contains logger failures involving multiple callers; these observations do not identify Town Road Lane as the cause of the latest crash. Private game logs are not included in public packages.

Pending settings can only finish flushing while the main-thread dispatcher continues running; process shutdown can terminate an unfinished write. The queue does not claim crash-proof persistence.

## Remaining release requirements

The official build and post-processing gate is complete. The candidate is ready to enter isolated gameplay testing, not public release.

The user selected a **new disposable test city** first. Use a separate test playset containing this local candidate, the three required asset packs, and their automatically required dependencies. The original Town Road Lane must be disabled in that playset. Do not load or save an established city in this first check.

Skyve is running, but both supported attempts to expose its window returned "launched app did not expose a targetable window". Explorer access was not approved by the app-access layer. The user reports using multiple desktops and a working Paradox launcher, with Skyve's launch button unreliable. **Skyve is needed only for playset management; launch through the working Paradox launcher.** A directly accessible Skyve window is needed to configure and verify the isolated playset. No playset was changed and no candidate was installed during these UI attempts. The user subsequently launched the original game; it must close before candidate installation.

After the Skyve window is available:

1. Create a separate test playset and record the original active playset so it can be restored.
2. Install the postprocessed candidate under a distinct local folder, check the original mod is disabled, and verify the asset packs and their dependencies are enabled. Do not edit subscribed package files.
3. Launch a new disposable city. Check the hotfix's versioned startup banner, absence of logger exceptions, clone counts, and successful UI/tool initialization.
4. Exercise automatic markings, manual lines, fills, per-node hiding, road edits, temporary previews, a closed road loop, settings persistence, and save/reload in the disposable city.
5. Test EU/NA and left-hand traffic, repeated loads in one process, missing dependencies, extensive markings, and a copy of an older modded save. Record results and compare idle/update costs before making performance claims.
6. Resolve any failures, rebuild and retest, then prepare the Paradox listing with source availability, original-author credit, AI-use disclosure, dependencies, incompatibilities, and test coverage. Publication remains a separate final step after review.

## Reproducing local checks

`verify-compile.ps1` calls Roslyn directly for quick reference checking. Supply the installed Managed folder, the matching official Entities SourceGenerators directory, and the SDK's csc.dll. Its verification output is deliberately marked as not postprocessed; the installable test candidate instead comes from the official Release build under artifacts/TownRoadLane. `tests/run.ps1` uses the installed .NET 10 reference pack and csc.dll to run the isolated regressions without Unity.

For standard builds, install the UI lockfile dependencies with `npm ci` in `src/TownRoadLaneUI`, then use the official game's modding toolchain to build Release. The build stages under artifacts. HotfixCheckOnly is available for SDK reference builds when NuGet settings are accessible. Standard SDK builds may download the .NET Framework reference-assembly package if its targeting pack is not installed; the direct verification compiler instead uses the installed game's assemblies.

Do not rename saved components, prefab names, the settings identity, or the TownRoadLane assembly to brand the fork. Preserve old layouts and explicitly test any future migrations. Preserve reviewed hashes in release records, decompile the relevant vanilla systems after each game update, and only update the compatibility baseline after comparison and checks.

## Upstream provenance

- Original source and license: https://github.com/mxerf/town-road-lane
- Logging issue with supplied stack trace: https://github.com/mxerf/town-road-lane/issues/1
- Proposed logging improvements used as groundwork: https://github.com/mxerf/town-road-lane/pull/4
- Proposed ordering improvements used as groundwork and corrected after compilation: https://github.com/mxerf/town-road-lane/pull/5
- Serialization/settings proposals reviewed; this derivative uses its own stricter version gate and polled save queue: https://github.com/mxerf/town-road-lane/pull/6 and https://github.com/mxerf/town-road-lane/pull/7
- Skyve classification: https://skyve-mod.com/compatibility

Neither the original logging report nor this source preview proves Town Road Lane caused your latest crash. Skyve's classification remains relevant until the deployed package is independently validated and its review updated.
