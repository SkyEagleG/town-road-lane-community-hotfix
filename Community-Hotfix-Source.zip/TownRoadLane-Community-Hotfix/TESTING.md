# Community Hotfix — first gameplay check

This is an unofficial test candidate based on mxerf's Town Road Lane, developed with AI assistance. The official Release build and 26 focused tests have passed. Gameplay validation is pending.

## Before launch

1. Close the game before installing or changing test playsets. Open **Skyve CS-II** for playset management. Create a separate playset named **Town Road Lane Hotfix Test** and record the name of the playset that was active before the test.
2. Add the local **Town Road Lane Community Hotfix** candidate. Its assembly name remains TownRoadLane for save compatibility. Keep the original subscribed Town Road Lane **disabled in this test playset**; do not unsubscribe or replace its cached files.
3. Enable the required packs: **97828**, **98624**, **99062**, plus any dependencies Skyve requires for those packs. Keep unrelated mods out of this initial test. Follow Skyve's dependency resolution instead of forcing a broken minimal list.
4. Verify the selected playset and that only one TownRoadLane assembly will load. The candidate log must show **Community Hotfix 1 (2.5.0.1)**.

The candidate ZIP contains a folder named TownRoadLaneCommunityHotfix. The expected local destination is `%USERPROFILE%\AppData\LocalLow\Colossal Order\Cities Skylines II\Mods\TownRoadLaneCommunityHotfix`. Installation can be performed by the agent once the isolated playset is available and the game is closed.

## Disposable city

1. With the test playset selected and verified, launch through your working **Paradox launcher**. Using Skyve's launch button is unnecessary. Start a new city on a built-in map. Use a name such as **TRL Hotfix Test**.
2. Reach the playable city and let the simulation run briefly. Check that the mod's panel opens with Ctrl+M and can close again.
3. Create a basic junction and a road loop. Check edge markings and parallel parking markings where applicable.
4. Draw a solid line and dashed line, change a line style, hide/show a piece, and delete a line. Create a simple triangular fill and a curved-edge fill. Check per-junction vanilla marking suppression.
5. Reshape and remove a test road. Use the road tool's temporary preview and cancel it. Check for errors, disappearing UI, continuous line respawning, or a crash.
6. Save as **TRL Hotfix Test 01**. Return to the menu, reload that test save, and check that lines and fills remain. Repeat a second load in the same process.
7. Change a setting, wait several seconds, restart the game, and verify persistence and restart-bound styles.

Record each step as passed, failed, or not tested. A successful menu launch alone is not a successful gameplay test.

## Evidence and later checks

- Preserve the new TownRoadLane.Mod.log and relevant Player.log separately from the original logs.
- Check initialization success, bounded diagnostics, and lack of repeated exceptions. Compare a short idle interval with a road-edit interval.
- Later checks need both themes, left-hand traffic, missing-dependency behavior, a city with many markings, and a copy of an older save. No performance or broad compatibility claim is justified before those checks.
- Use a copied city for migration tests. Keep original save files intact.

The package is for validation. Its public name, source/credits, AI disclosure, dependencies, and release notes will be reviewed before any Paradox Mods upload.
