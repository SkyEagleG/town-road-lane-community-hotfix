# Town Road Lane Community Hotfix: 1.6.4f1 compatibility review

Reviewed 2026-11-16. Result: **confirmed activation refusal in 2.5.0.1; statically reviewed, built 2.5.0.2 test candidate; gameplay validation pending.** No current-release marking algorithm defect has been established. This is not a claim that the candidate is ready for publication.

## Scope and provenance

- Genuine supplied hotfix source: `work/town-road-lane-hotfix`, Git HEAD `7df4c79584940a649a1dfbf47dcc925c40cab87c`, version 2.5.0.1. Its pre-existing publication XML edits and screenshot files were preserved in the review snapshot. A Git HEAD alone does not identify those uncommitted listing changes.
- Isolated baseline snapshot: `b6be7f13fde5430a086b0cf3324552c7acba8dcd`. The candidate is in a separate folder, `work/town-road-lane-1.6.4-review`. Its resulting commit is supplied in `SCANNER_HANDOFF.json` with the delivery.
- Original upstream baseline recorded by this project: mxerf/town-road-lane commit `6ffd1e874ab70e60834e76ad15cae08508d991a8`, version 2.5.0. This review did not fetch or re-audit a newer upstream release. The separately supplied original-mod audit has now been reconciled against genuine source and current installed game types; see `INDEPENDENT_AUDIT_RECONCILIATION.md`.
- Locally cached published hotfix: Paradox mod 163405, cache revision directory `163405_1`, assembly `TownRoadLane`, version **2.5.0.1**, SHA256 `BAEBBDEB7169DBC78CF446AE5960A7EBED8B2555CED1802FDEEC4ED414AB2DA4`. The listing configuration and prior publication records also identify 2.5.0.1. Live remote listing/backend state was not rechecked; cache revision 1 is not the user-facing version number.
- Target installation: Windows Steam Cities: Skylines II **1.6.4f1**, confirmed from local launcher settings and assembly fingerprints, not inferred solely from the scanner. This review is limited to those installed binaries.
- Candidate: assembly `TownRoadLane`, **2.5.0.2**, revised managed DLL SHA256 `2E620C27263642DA99981209FD493B98D9DADEEED9F2F4D02D0943679CBFC0A9`. This artifact is distinct from the installed/published 2.5.0.1 package and supersedes the earlier unpublished 2.5.0.2 candidate whose DLL hash began `8798E4E4`.

No game was launched, no saves were opened or changed, no package was installed, no publication command was run, and no messages were sent to third parties. The original working tree and cached published DLL were left unchanged. Public patch notes were consulted read-only.

## Prioritized findings

### P1 — Confirmed: old exact-binary gate refuses the installed release

In the supplied 2.5.0.1 source, `src/TownRoadLane/Utilities/CompatibilityBaseline.cs:13` and `:14` accept only the reviewed 1.6.2f1 Game/ECS fingerprints. `Mod.cs:53-59` checks this before settings, UI registration and lane-system takeover. An unknown pair returns early, leaving vanilla enabled.

The local `TownRoadLane.Mod.log` records the actual refusal on November 16 at 15:20:06, including the current Game and Entities hashes and the message that the hotfix is inactive. The delivery includes a minimal excerpt. Therefore **activation is blocked**, which explains an unavailable tool without a load crash. This is deliberate fail-closed behavior, not evidence that the underlying generator crashes on 1.6.4f1. The game's “likely incompatible” and Skyve's older-version labels alone did not establish this finding; the log does.

| Assembly | Old accepted 1.6.2f1 SHA256 | Installed 1.6.4f1 SHA256 |
|---|---|---|
| Game.dll | AAEE15C4FA41C130ABAA1183840667E4FAAE531D67E8A9FA7536618EFFA2F86A | F076DF4B70AA0F21A80345E03A052CA2273BC6754F41DAB7E63D837837A43745 |
| Unity.Entities.dll | 07D9CB32BF935A88ECD5FE0BAFF31D2BC7E828F6DEA31619300A50DD9E2C2871 | 7E6D9ED7DF5295652FCCDB609D3D092CABB5A3FDB91336702D77381A1D42ED86 |

### P1 — Static review supports a tightly pinned candidate, not a broad compatibility claim

Freshly decompiled installed types were compared with the preserved 1.6.2 review baseline using SHA256 of the complete decompiled text. All seven comparisons were byte-for-byte identical: `Game.Net.SecondaryLaneSystem`, `Game.Common.SystemOrder`, `Game.UpdateSystem`, `Game.Prefabs.PrefabSystem`, `Unity.Entities.EntityManager`, `Colossal.Logging.ILog`, and `Game.Modding.ModSetting`. See `evidence/integration-comparisons.json` for hashes and local evidence paths. Decompiler equality for these types is not proof that every method in every dependency is unchanged; it does not test native rendering or runtime state.

The supplied hotfix also compiled **unchanged** against current installed references before edits. The candidate subsequently passed reference compilation and the official toolchain's IL/Burst postprocessing. These checks establish retained compiler-visible API compatibility and provide specific evidence for retaining the current replacement implementation. They do not establish gameplay compatibility.

`Systems/Emission/CustomSecondaryLaneSystem.cs:1935-2017` still creates the owner query, refreshes type handles, schedules with its incoming dependency, gives the resulting producer handle to `ModificationBarrier4B`, and stores that handle as its outgoing dependency. `Mod.cs:123-127` still registers it in Modification4B, where current `SystemOrder` permits that barrier. The current schedule still places area geometry in Modification2B. No changed ordering or barrier contract was found that justified editing these paths.

The copied generator remains a maintenance-sensitive integration. Exact fingerprint gating is retained. A future release with different hashes requires another review; it is not automatically supported by this candidate.

### P1 — Pending: UI/rendering and actual takeover on 1.6.4f1

The [official Seasonal Shift announcement](https://store.steampowered.com/news/app/949230/view/704410206513135889) documents an updated Coherent UI framework. This is a reason to test the interface, not proof that Town Road Lane's interface is broken.

The current installed UI bundle contains the external module/slot names used by this frontend: `cohtml/cohtml`, `cs2/api`, `cs2/bindings`, `cs2/input`, `cs2/l10n`, `cs2/modding`, `cs2/ui`, `cs2/utils`, `GameTopLeft`, and `GameTopRight`. String presence does not guarantee unchanged export shapes or successful registration. Frontend type checking uses the repository's retained declarations, not newly generated 1.6.4 runtime declarations.

The binding namespace still matches: C# `Systems/UI/ExtendedUISystemBase.cs:43` uses `TownRoadLane`, and frontend `src/bindingGroup.ts:3` uses the same string. `src/index.tsx:9-11` retains the two named toolbar/panel attachment slots. C# binding calls compile against the current `Colossal.UI.Binding` APIs; frontend type checking and webpack succeed. There is no demonstrated binding mismatch to repair. Actual panel display, commands, translated strings, input, style choices, clone rendering and live marking rebuilds remain untested for this candidate.

### P2 — Initialization, dependencies and saved data: retained, with specific limits

- **Initialization/takeover:** `Mod.cs:118-127,163-172` obtains the vanilla system, rejects an already-disabled replacement, registers systems, then disables vanilla only after registration succeeds. Failure calls cleanup. `Mod.cs:177-200` completes tracked jobs, disables own systems and restores vanilla only when this instance owns the replacement. No new incompatibility was established in these branches.
- **Prefab startup:** `Systems/Prefabs/VanillaSurfaceLateClone.cs:85-107` uses existing boot/loading state checks and bounded readiness polling. Current compiler-visible APIs still exist, and the complete `PrefabSystem` comparison matched. Reflection-based field copying at `:190-195`, prefab names/material properties and external pack contents are not proven stable by compilation. Retained clone names matter to saved areas and were not changed.
- **Dependencies:** publication IDs remain G87 Road Markings 97828, Stripes and Chevrons 98624, and Vanilla Curb 99062, plus their dependencies. Current active playset, resolved asset-pack revisions, missing-prefab behavior and conflicts with other lane replacements were not independently established. The original mod and hotfix must not run together.
- **Serialization:** the final postprocessed candidate was compared with the cached published 2.5.0.1 assembly. All **nine** serializable component identities, public instance-field sequences/types, legacy aliases and writer versions matched. All component and migration source files are unchanged. Existing focused tests cover shipped writer sequences, selected legacy readers, and rejection of unknown versions. This is stronger than assuming a save will migrate, but it is not a real-world save round trip.
- **Migration:** `Systems/Emission/MarkingPairMigrationSystem.cs:53-90` still snapshots the old buffer before structural changes and registers before emission. No migration or serialization rewrite is justified by the evidence. Broad older-save migration remains a gameplay test.
- **Earlier reports:** RoadConstructionSystem and VehicleController errors from the historical heavily modded session do not establish a defect in this candidate. The new inactivity message occurs before the hotfix registers those gameplay systems. No speculative catch-all exception handling or unrelated mod repair was added.

## Changes made and why

Four shipped C# files changed relative to the supplied 2.5.0.1 baseline; the test program also changed:

1. `Utilities/CompatibilityBaseline.cs`: pins this isolated candidate to the exact installed 1.6.4f1 Game/ECS pair **after** the above comparison and compilation review; preserves the dual-hash fail-closed check and vanilla fallback. The comment and success reason explicitly distinguish static review from pending gameplay validation. The 1.6.2 pair is not added as a second supported target for this newly compiled artifact.
2. `Mod.cs`: startup diagnostic takes its version from the assembly instead of permanently claiming 2.5.0.1; identifies this as an unvalidated 1.6.4f1 test candidate.
3. `Systems/Topology/MarkingAreaTopologySystem.cs`: fixes a confirmed diagnostic-suppression gap identified while reconciling the independent audit. New failures at the same node/area index can warn again when the existing topology input hash changes; successful-area reset and topology-pass cleanup are retained. This changes diagnostics, not geometry construction or retries.
4. `Utilities/RevisionWarnings.cs`: isolates that diagnostic tracking and limits warning resets during rapid input changes with a five-second interval. Intermediate edits inside that interval may remain unreported if no later eligible rebuild occurs. Integer hash collisions and external geometry not represented in the existing topology hash remain limitations.

`tests/Program.cs` and its runner add five focused diagnostic-lifecycle and rapid-edit regression cases, bringing the suite to 31 passing checks. See `INDEPENDENT_AUDIT_RECONCILIATION.md` for the original/existing/proposed comparison, verified scheduler/job contracts and suggestions deliberately left unmerged.

`PublishConfiguration.xml` is a local draft only: version 2.5.0.2, target 1.6.4f1*, explicit candidate title/status and historical/current test distinction. An Update log is appended at the bottom of its LongDescription. The metadata pattern permits game build suffixes; the independent runtime check still requires both exact fingerprints. Paradox mod ID 163405, GitHub link and dependency IDs are preserved. No live listing was changed.

`verify-compile.ps1` now reads the version from that XML instead of stamping reference-check artifacts 2.5.0.1 forever. `NuGet.Offline.Config` permits metadata restore with no package feeds. README points to this current review and marks the old reports as historical. Frontend source and lockfile are unchanged; the rebuilt `.mjs` banner now says 2.5.0.2 through the existing version pipeline. The delivered frontend files are downloadable with the candidate.

No marking algorithm, scheduling, saved-data identity/layout, dependency version or unknown-build bypass was changed. If subsequent evidence identifies a functional defect, it needs a separate targeted repair.

## Validation performed

| Check | Result and limit |
|---|---|
| Installed build and fingerprints | Confirmed 1.6.4f1; five dependency hashes recorded |
| Actual old gate refusal | Confirmed in local mod log, with exact current fingerprints |
| Seven historical/current type comparisons | All complete decompiled-text hashes match |
| Original unmodified source on current APIs | Reference compilation passed |
| Candidate reference compilation | Passed with installed Entities source generators |
| Focused regression suite | **31 passed**; actual diagnostic tracker plus retained serialization/helper stubs, not Unity runtime coverage |
| Frontend dependency reconstruction | `npm ci --ignore-scripts --offline` succeeded from existing cache; no versions changed |
| Frontend typecheck / production bundle | Passed; one legacy Sass JS API deprecation warning |
| Official Release build / IL / Burst | Passed; Windows, macOS and Linux native outputs produced by the stock postprocessor; this does not establish supported gameplay on those platforms |
| Final binary saved-component comparison | Nine identities/layouts/aliases/writer versions unchanged |
| Final metadata | Assembly TownRoadLane 2.5.0.2; UI banner 2.5.0.2 |
| Cached published DLL | SHA256 unchanged after build |
| In-game test / installation / publishing | Not performed |

The initial `--no-restore` build lacked the new folder's build metadata. Automatic approval review then rejected a restore that could have consulted NuGet feeds. A feed-free restore using installed framework references succeeded; no override of that rejection or online package restore was used. The final build used `--no-restore`. Build output was explicitly checked to stage within the isolated workspace's `artifacts/TownRoadLane`, not the game's Mods folder.

## Reproduction and remaining evidence

Use the installed official modding toolchain and .NET Framework 4.8 reference assemblies. In the supplied full source folder:

```powershell
npm --prefix src/TownRoadLaneUI ci --ignore-scripts --offline --cache <existing-npm-cache>
npm --prefix src/TownRoadLaneUI run typecheck
dotnet restore src/TownRoadLane/TownRoadLane.csproj --configfile NuGet.Offline.Config -p:NuGetAudit=false -p:AutomaticallyUseReferenceAssemblyPackages=false
dotnet build src/TownRoadLane/TownRoadLane.csproj -c Release --no-restore -p:NuGetAudit=false -p:AutomaticallyUseReferenceAssemblyPackages=false
```

The regression runner and reference compiler take explicit SDK/reference/generator paths; see their parameter blocks. Do not run publishing targets. Offline frontend reconstruction requires a populated cache; missing packages need a separate download decision.

Needed before a release decision: candidate-specific startup and post-test logs; exact enabled playset/dependency revisions; disposable-save behavior; visual/UI results after a full restart; settings persistence; older markings and migration where an appropriate backed-up source save exists. Do not use historical 1.6.2 gameplay success as current-release validation. If the user is still testing installed 2.5.0.1, its continued inactivity is expected and is not a test of this separately staged 2.5.0.2 candidate.

### Proposed disposable-save checks (not executed)

1. In a deliberately chosen minimal test playset, use only one hotfix candidate plus required assets/dependencies. Record game version, mod DLL version/hash and asset revisions. Check startup for candidate 2.5.0.2 and successful takeover; no unreviewed-build refusal, repeated exceptions or diagnostic flood. Stop if activation is not verified.
2. Use a new disposable city. Open via button and Ctrl+M; inspect panel, translated text, hotkeys, style choices and pins. Create/edit/delete solid and dashed lines, curves, fills and hide/reset vanilla markings. Verify tool cancellation and overlays.
3. Test ordinary roads and parking marks; edit/upgrade/bulldoze a marked road and junction. Include flat/sloped roads and a few surface-clone fills. Watch for missing prefabs, invalid command-buffer errors, job/safety exceptions, stale marks, or visual fading. Distinguish camera/slope effects from persistent state loss.
4. Save under a new test name; reload through the menu, then fully exit/restart and reload. Compare line/area geometry and styles. Change a setting, apply it through the documented reload/restart path, and confirm persistence without overwriting a valuable save.
5. Only afterward, separately test a disposable copy of a known older marked city. Never run both original and replacement. If a suitable pre-removal save cannot load independently, report migration coverage as unavailable rather than claiming a pass. Capture exact reproduction steps and neighboring log entries for failures.
6. Exercise an invalid-area edit/recovery sequence: unchanged failures should not flood the log; changed inputs can warn afresh subject to the five-second changed-revision interval. Broader modded-city tests, performance, left-hand traffic and alternate themes remain additional coverage, not implied passes.

The supplied evidence hashes, scanner handoff, complete replacement C# blocks, downloadable source/config/frontend files and binary hashes make the candidate reviewable. Proprietary game assemblies, their decompiled source, raw personal logs, saves, account data and unrelated publisher tooling are intentionally excluded from the delivery.
