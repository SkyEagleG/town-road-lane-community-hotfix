using System.Collections.Generic;

namespace TownRoadLane.Utilities
{
    /// <summary>Diagnostic suppression only; never controls geometry or retry decisions.</summary>
    internal sealed class RevisionWarnings<TKey>
    {
        // Dragging an invalid area can change its hash every frame. A new input revision
        // must not turn diagnostic deduplication back into a per-frame warning stream.
        private const float ChangedInputWarningInterval = 5f;
        private sealed class State
        {
            internal readonly int Revision;
            internal float LastWarningTime;
            internal readonly HashSet<(int slot, int reason)> Warnings = new();
            internal State(int revision) { Revision = revision; }
        }

        private readonly Dictionary<TKey, State> _states = new();
        internal int Count => _states.Count;

        internal bool ShouldWarn(TKey key, int revision, int slot, int reason, float now)
        {
            if (!_states.TryGetValue(key, out var state))
            {
                state = new State(revision);
                _states[key] = state;
            }
            else if (state.Revision != revision)
            {
                if (now - state.LastWarningTime < ChangedInputWarningInterval) return false;
                state = new State(revision);
                _states[key] = state;
            }
            if (!state.Warnings.Add((slot, reason))) return false;
            state.LastWarningTime = now;
            return true;
        }

        internal void ClearSlot(TKey key, int slot)
        {
            if (!_states.TryGetValue(key, out var state)) return;
            state.Warnings.RemoveWhere(warning => warning.slot == slot);
            if (state.Warnings.Count == 0) _states.Remove(key);
        }

        internal void RetainOnly(ISet<TKey> alive)
        {
            if (_states.Count == 0) return;
            var gone = new List<TKey>();
            foreach (var key in _states.Keys)
                if (!alive.Contains(key)) gone.Add(key);
            foreach (var key in gone) _states.Remove(key);
        }

        internal void Clear() => _states.Clear();
    }
}
