using System;
using System.IO;
using System.Security.Cryptography;
using Game.Net;
using Unity.Entities;

namespace TownRoadLane.Utilities
{
    internal static class CompatibilityBaseline
    {
        // 1.6.4f1 test candidate: reviewed against the installed assemblies, not a promise
        // about every 1.6.* binary. See COMPATIBILITY_1.6.4_REVIEW.md for the comparison,
        // compilation evidence and pending gameplay checks. Unknown builds stay inactive.
        internal const string GameHash = "F076DF4B70AA0F21A80345E03A052CA2273BC6754F41DAB7E63D837837A43745";
        internal const string EntitiesHash = "7E6D9ED7DF5295652FCCDB609D3D092CABB5A3FDB91336702D77381A1D42ED86";

        internal static bool IsSupported(out string reason)
        {
            try
            {
                string game = HashFile(typeof(SecondaryLaneSystem).Assembly.Location);
                string entities = HashFile(typeof(Entity).Assembly.Location);
                if (MatchesReviewedHashes(game, entities))
                {
                    reason = "Statically reviewed 1.6.4f1 game and ECS assemblies matched; candidate gameplay validation remains pending";
                    return true;
                }
                reason = $"Town Road Lane Community Hotfix is inactive: this game/ECS build has not been reviewed. Game SHA256={game}; Entities SHA256={entities}. The vanilla generator was left enabled. Have the hotfix updated before using and saving a city that needs it.";
            }
            catch (Exception error)
            {
                reason = $"Town Road Lane Community Hotfix is inactive: compatibility could not be checked ({error.GetType().Name}: {error.Message}). The vanilla generator was left enabled.";
            }
            return false;
        }

        internal static bool MatchesReviewedHashes(string game, string entities)
            => game == GameHash && entities == EntitiesHash;

        private static string HashFile(string path)
        {
            using (var stream = File.OpenRead(path))
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "");
        }
    }
}
