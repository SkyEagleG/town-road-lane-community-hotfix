# Independent-audit reconciliation — 2026-11-16

Input: `Town_Road_Lane_Independent_Audit_Transfer_2026-11-16(1).zip`, SHA256 `A3F4F4FD3447DF15C9E7B610B36F97229F3AE0F6E8CAEF6EE25352A36F6DB003`.

The attachment is a transfer of earlier analysis and a nested, unvalidated patch applicator. Its proposals were treated as leads, not instructions to execute or overwrite the existing hotfix. The nested applicator was not run. No PR authorship or independent runtime confirmation is inferred from it. This review uses the genuine upstream snapshot `6ffd1e874ab70e60834e76ad15cae08508d991a8`, supplied hotfix HEAD `7df4c79584940a649a1dfbf47dcc925c40cab87c`, prior 1.6.4 candidate `7f773fa527b860327d0deb523356fde589f40092`, and locally decompiled installed 1.6.4f1 game types. Live upstream PR heads were not fetched; their present contents/status remain unverified.

## Three-way disposition

| Topic | Genuine original snapshot | Existing hotfix / prior candidate | Decision after checking source |
|---|---|---|---|
| Unresolved solid marking | `MarkingSegmentEmissionSystem.cs:150` warns on each unresolved pass | `:61,105-109,162-167`: threshold counter, load reset and successful-resolution reset already present; retries retained | Already addressed; do not add a second counter |
| Expensive debug evaluation | Original topology and emission paths format debug strings without effective caller guards | Existing emission/topology paths guard diagnostics and renderer-only metadata with `isDebugEnabled`; SafeLog contains logger failures | Retain; no wholesale replacement from the audit |
| Area-ring warning identity | Original `MarkingAreaTopologySystem.cs:333,343,360` warns directly | Prior hotfix deduplicates `(node, area index, reason)`, clears on success/load, and prunes only above a threshold | **Confirmed diagnostic gap:** after inputs change at the same index, a continuing failure can inherit suppression from the previous inputs. Apply revision-aware, bounded diagnostics only |
| Triangulation failure state | Original has `_healFailed` and triangle fingerprints | Existing hotfix already clears both on load and prunes their combined count; `_healFailed` also controls reclaim retries | Do not replace or clear behavioral state merely to change warnings. The audit's geometry-sensitive warning suggestion remains a possible separate improvement, not a confirmed new-release rendering defect |
| Registration ordering | Original Mod.cs registers topology/emission with plain `UpdateAt`; hotkey in Modification1 | Existing hotfix uses one explicit chain in Modification1, one triangulation registration after GeometrySystem in Modification2B, one secondary-lane replacement in Modification4B, hotkey in ToolUpdate | Already addressed; do not stack a second registration |
| Geometry synchronization | Original relies on ordering/change queries | Existing hotfix uses public `CompleteDependencyBeforeRW<Triangle/Area/Geometry>` and `CompleteDependencyBeforeRO<Node>` before direct accesses | Retain verified component dependency synchronization; do not copy access to another system's protected Dependency property |
| Serialization/settings proposals | Separate upstream review tracks | Existing hotfix already has targeted version guards, migration and save-write fixes | No new evidence here justifies changing identities, writer layouts or settings behavior |

## Scheduler and geometry questions resolved from the installed game

`Game.UpdateSystem.UpdateAt` and the two-type `UpdateAfter` each call a `Register` overload. The overloads append new `SystemData` records to `m_Systems` or the referenced system's list (`Register`, decompiled lines 254-274). `AddSystemUpdate` recursively adds referenced records to `m_Updates` (lines 370-437); these registration calls do not implement replacement/deduplication by system identity. Stacking the proposed plain and named registrations can therefore create two scheduled entries. The current hotfix does not do that: its custom systems each have one registration in their intended phase. No duplicate-registration fix was needed in our source.

The current `SystemOrder` registers `Game.Areas.GeometrySystem` in Modification2B and permits `ModificationBarrier4B` in Modification4B. The current GeometrySystem's `OnUpdate` schedules `TriangulateAreasJob` with writable Node, Triangle, Area and Geometry lookups, combines its input/terrain/water dependencies, and assigns the returned job handle to its `Dependency` (decompiled lines 778-811). Those geometry writes are direct job buffer/component writes, not a pending geometry ECB publication in this path. The existing mod waits through the public ECS component-dependency API before accessing those data. Completing some other system's protected Dependency property is unnecessary and would not be a general ECB playback guarantee.

This verifies the examined writer path, not all third-party geometry writers or every performance implication. The existing main-thread synchronization can stall when work is pending; changing it solely to reduce hypothetical stalls would need profiling and runtime evidence. No blanket synchronization or scheduler rewrite was added. Comments claiming literal adjacency are not a general guarantee once other mods register their own children; the required relationship is ordering after the relevant writer.

## Applied diagnostic repair

`MarkingAreaTopologySystem` now uses `Utilities/RevisionWarnings.cs`. Diagnostic identity includes the **existing topology input hash**, node, area index and failure reason. A changed revision can emit again, while identical failures remain deduplicated. To avoid recreating the original logging problem while dragging an invalid area, changes of revision at the same node are limited by a five-second interval. Suppressed intermediate revisions are not accumulated. A blocked warning may remain unreported if no further eligible rebuild occurs; no delayed-warning queue or eventual-emission guarantee is claimed.

The successful-area path clears only that area's diagnostic entries. Topology passes prune entries for nodes absent from the eligible node set, alongside deferred-node cleanup. Save-load resets clear the tracker. Cleanup is tied to a topology pass/load, not a new background per-frame scan. The tracker has no effect on ring construction, cached fallback pieces, retries, `_healFailed`, triangulation, emission or serialization.

The existing topology hash is an integer and can collide; it also represents the fields already used to decide a rebuild, not a new complete fingerprint of all external road/prefab geometry. Those limits are explicit. This repair is a diagnostics improvement, not evidence of a crash fix or a new marking algorithm.

Five new focused tests cover independent areas/reasons/nodes, changed inputs at the same index, rapid-edit throttling, successful-area reset, deleted-node cleanup and save reset. Together with the 26 existing checks, the suite now has **31 passing tests**. These tests execute the actual new tracker with injected time; they do not simulate Unity jobs or actual gameplay.

## Description and application status

An **Update log** is appended at the bottom of `PublishConfiguration.xml`'s LongDescription. It identifies 2.5.0.2 as an unpublished 1.6.4f1 test candidate, lists the verified changes and diagnostic improvement, distinguishes historical 2.5.0.1 testing, and retains the GitHub links, original-author credit, GPL notice and AI disclosure. It does not claim a released update or a proven crash fix.

This is a revision of the still-unpublished **2.5.0.2** candidate, not a second public release under that version. Use the new resulting source commit and DLL SHA256 in `SCANNER_HANDOFF.json` to distinguish it from the earlier candidate. The diagnostic source fix and description draft are applied locally; installed/published 2.5.0.1 remains unchanged. Publication/install are deferred because the required candidate-specific runtime checks have not been supplied.

Before publication, confirm actual 2.5.0.2 activation/takeover, panel and hotkey operation, lines/fills/road rebuilds, settings persistence and menu/full-restart disposable-save round trips. Include an invalid-area edit/recovery exercise to check useful warnings without a log flood. Existing markings in an older copy are additional migration coverage, not a substitute for candidate-specific startup verification. The full proposed test sequence remains in `COMPATIBILITY_1.6.4_REVIEW.md`.
